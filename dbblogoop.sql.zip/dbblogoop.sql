-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 12 mrt 2019 om 15:17
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `user_id`, `author`, `body`, `date_time`) VALUES
(1, 1, 1, 'Ruben Lamoot', 'leuk', '2019-02-24 07:59:23'),
(2, 1, 2, 'Tom Vanhoutte', 'Mooi', '2019-02-24 08:27:09'),
(3, 1, 1, 'Ruben Lamoot', 'fantastisch', '2019-03-04 11:51:58'),
(6, 2, 1, 'Ruben Lamoot', 'ik zou zeggen : bla bla', '2019-03-04 13:34:38'),
(7, 2, 1, 'Ruben Lamoot', '', '2019-03-04 13:36:18');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `caption`, `description`, `filename`, `alternate_text`, `type`, `size`, `created_at`, `updated_at`) VALUES
(1, 'Taj Mahal', 'Taj Mahal', '<p>lange tekst over de Taj Mahal met veel gezever. Bla bla bla Bla bla bla Bla bla bla Bla bla bla Bla bla bla Bla bla bla</p>', 'Taj.jpg', 'Iets over de Taj', 'image/jpeg', 8063, '2019-02-24 07:54:43', '2019-02-24 07:54:43'),
(2, 'Big Ben', 'Londen', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'bigben.jpg', 'Toren in Londen', 'image/jpeg', 8340, '2019-02-24 08:06:53', '2019-02-24 08:06:53'),
(3, 'Piramides van Cheops', 'Giza', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla.</p>', 'cheops.jpg', 'piramide in Egypte', 'image/jpeg', 7517, '2019-02-24 08:00:38', '2019-02-24 08:15:35'),
(4, 'Chinese Muur', 'wall', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla.</p>', 'chinesewall.jpg', 'china', 'image/jpeg', 11284, '2019-02-24 08:00:51', '2019-02-24 08:16:38'),
(5, 'Eiffeltoren', 'eiffel', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'eiffeltoren.jpg', 'Parijs', 'image/jpeg', 8373, '2019-02-24 08:00:25', '2019-02-24 08:19:07'),
(6, 'Atomium', 'atomium', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'atomium.jpg', 'Brussel', 'image/jpeg', 10717, '2019-02-24 08:00:37', '2019-02-24 08:19:40');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `photo`) VALUES
(1, 'Komkommer', '<p>Dit is een komkommer. ja hoor.</p>', 'komkommer_gemini.jpg'),
(2, 'Paprika', '<p>Dit is een paprika.</p>', 'paprika_esmeralda.jpg'),
(3, 'Radijs', '<p>Dit is een radijs</p>', 'radijs_riesenbutter.jpg'),
(4, 'stokslaboon', 'dit is eens tokslaboon', 'stokslaboon.jpg'),
(5, 'tomaat tumbling', 'dit is een tomaat tumbling', 'tomaat_tumbling.jpg'),
(6, 'tomaat whitebeef', 'dit is een tomaat whitebeef', 'tomaat_whitebeef.jpg'),
(8, 'Wortel Nantes', '<p>Dit is een wortel. Haha.</p>', 'wortel_nantes_1552306704.jpg');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `role`) VALUES
(1, 'administrator'),
(2, 'subscriber'),
(3, 'author'),
(4, 'user'),
(5, 'reviewer');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `subcomments`
--

DROP TABLE IF EXISTS `subcomments`;
CREATE TABLE IF NOT EXISTS `subcomments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `subcomments`
--

INSERT INTO `subcomments` (`id`, `comment_id`, `user_id`, `body`, `date_time`) VALUES
(1, 2, 1, 'vind ik ook', '2019-03-04 12:40:24'),
(2, 2, 1, 'prachtig toch?', '2019-03-04 12:43:59'),
(3, 1, 3, 'geweest?', '2019-03-04 12:54:21'),
(4, 2, 3, 'waaaaw', '2019-03-04 12:57:04'),
(5, 3, 3, 'kweet nie oe schoon', '2019-03-04 13:04:09'),
(6, 1, 2, 'ik heb nog geholpen met dat te bouwen.', '2019-03-04 13:30:36'),
(7, 3, 2, 'Ge weet et', '2019-03-04 13:31:50'),
(8, 5, 2, 'commentaar op bla bla bla', '2019-03-04 13:33:40'),
(9, 5, 2, 'nog meer commentaar op bla bla bla', '2019-03-04 13:34:00'),
(10, 5, 1, 'ook bla bla bla', '2019-03-04 13:34:35'),
(11, 7, 1, 'bla bla bla', '2019-03-04 13:37:14'),
(16, 1, 1, 'comment', '2019-03-12 13:25:35'),
(17, 3, 1, 'halloo', '2019-03-12 13:43:54'),
(18, 3, 1, 'test2', '2019-03-12 13:47:39'),
(19, 7, 1, 'bla en nog eens bla', '2019-03-12 13:49:35'),
(20, 7, 1, 'en nog meer bla', '2019-03-12 13:50:20'),
(21, 1, 1, 'comment op 1', '2019-03-12 13:51:10'),
(22, 1, 1, '2e comment op 1', '2019-03-12 13:58:42'),
(23, 1, 1, 'comment ok?', '2019-03-12 14:05:41');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`, `admin`) VALUES
(1, 'Ruben', '1234', 'Ruben', 'Lamoot', 'avatar_1550997746.png', 1),
(2, 'Tom', '1234', 'Tom', 'Vanhoutte', 'avatar2_1550997868.jpg', 0),
(3, 'Lore', '1234', 'Lore', 'Vanhooren', 'avatar3_1550997900.jpg', 0),
(4, 'Brent', '1234', 'Brent', 'Vanhooren', 'avatar10_1552314433.jpg', 0),
(5, 'Tara', '1234', 'Tara', 'Vandevenne', 'avator11_1552396085.jpg', 0),
(6, 'Tester', '1234', 'Test', 'Testertjes', 'avatar8_1552396135.jpg', 1),
(7, 'Marieke', '1234', 'Marieke', 'Decabooter', 'avatar7_1552403719.jpg', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE IF NOT EXISTS `users_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users_roles`
--

INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 3),
(3, 4),
(4, 4),
(1, 3),
(5, 2),
(5, 3),
(6, 1),
(6, 2),
(6, 4),
(7, 5);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
