-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 10 mrt 2019 om 10:24
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `user_id`, `author`, `body`, `date_time`) VALUES
(1, 1, 1, 'Ruben Lamoot', 'leuk', '2019-02-24 07:59:23'),
(2, 1, 2, 'Tom Vanhoutte', 'Mooi', '2019-02-24 08:27:09'),
(3, 1, 1, 'Ruben Lamoot', 'fantastisch', '2019-03-04 11:51:58'),
(6, 2, 1, 'Ruben Lamoot', 'ik zou zeggen : bla bla', '2019-03-04 13:34:38'),
(7, 2, 1, 'Ruben Lamoot', '', '2019-03-04 13:36:18');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `caption`, `description`, `filename`, `alternate_text`, `type`, `size`, `created_at`, `updated_at`) VALUES
(1, 'Taj Mahal', 'Taj Mahal', '<p>lange tekst over de Taj Mahal met veel gezever. Bla bla bla Bla bla bla Bla bla bla Bla bla bla Bla bla bla Bla bla bla</p>', 'Taj.jpg', 'Iets over de Taj', 'image/jpeg', 8063, '2019-02-24 07:54:43', '2019-02-24 07:54:43'),
(2, 'Big Ben', 'Londen', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'bigben.jpg', 'Toren in Londen', 'image/jpeg', 8340, '2019-02-24 08:06:53', '2019-02-24 08:06:53'),
(3, 'Piramides van Cheops', 'Giza', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla.</p>', 'cheops.jpg', 'piramide in Egypte', 'image/jpeg', 7517, '2019-02-24 08:00:38', '2019-02-24 08:15:35'),
(4, 'Chinese Muur', 'wall', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla.</p>', 'chinesewall.jpg', 'china', 'image/jpeg', 11284, '2019-02-24 08:00:51', '2019-02-24 08:16:38'),
(5, 'Eiffeltoren', 'eiffel', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'eiffeltoren.jpg', 'Parijs', 'image/jpeg', 8373, '2019-02-24 08:00:25', '2019-02-24 08:19:07'),
(6, 'Atomium', 'atomium', '<p>Lange tekst. Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla, Bla bla bla bla</p>', 'atomium.jpg', 'Brussel', 'image/jpeg', 10717, '2019-02-24 08:00:37', '2019-02-24 08:19:40');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `subcomments`
--

DROP TABLE IF EXISTS `subcomments`;
CREATE TABLE IF NOT EXISTS `subcomments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `subcomments`
--

INSERT INTO `subcomments` (`id`, `comment_id`, `user_id`, `body`, `date_time`) VALUES
(1, 2, 1, 'vind ik ook', '2019-03-04 12:40:24'),
(2, 2, 1, 'prachtig toch?', '2019-03-04 12:43:59'),
(3, 1, 3, 'geweest?', '2019-03-04 12:54:21'),
(4, 2, 3, 'waaaaw', '2019-03-04 12:57:04'),
(5, 3, 3, 'kweet nie oe schoon', '2019-03-04 13:04:09'),
(6, 1, 2, 'ik heb nog geholpen met dat te bouwen.', '2019-03-04 13:30:36'),
(7, 3, 2, 'Ge weet et', '2019-03-04 13:31:50'),
(8, 5, 2, 'commentaar op bla bla bla', '2019-03-04 13:33:40'),
(9, 5, 2, 'nog meer commentaar op bla bla bla', '2019-03-04 13:34:00'),
(10, 5, 1, 'ook bla bla bla', '2019-03-04 13:34:35'),
(11, 7, 1, '', '2019-03-04 13:37:14');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`, `admin`) VALUES
(1, 'Ruben', '1234', 'Ruben', 'Lamoot', 'avatar_1550997746.png', 1),
(2, 'Tom', '1234', 'Tom', 'Vanhoutte', 'avatar2_1550997868.jpg', 0),
(3, 'Lore', '1234', 'Lore', 'Vanhooren', 'avatar3_1550997900.jpg', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
