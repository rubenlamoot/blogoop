-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 01 mrt 2019 om 10:47
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `user_id`, `author`, `body`, `date_time`) VALUES
(1, 1, 2, 'Ruben', 'bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla', '2019-02-18 13:10:00'),
(2, 1, 3, 'Lore', 'bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla', '2019-02-18 13:10:00'),
(3, 1, 5, 'Brent', 'bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla bla blal bla bla bla bla', '2019-02-18 13:10:00'),
(4, 2, 4, 'Marieke', 'nog meer bla blal bla bla bla bla bla blal bla bla bla bla', '2019-02-18 13:10:00'),
(5, 1, 1, 'Martijn', 'e wel nog meer va\r\n                ', '2019-02-18 13:10:00'),
(6, 1, 12, 'Neville', 'ma rieke gie da ier niet\r\n                ', '2019-02-18 13:10:00'),
(7, 1, 1, 'Tara', 'en nog meer bla bla bla bla\r\n                ', '2019-02-18 13:10:36'),
(11, 2, 2, 'Ruben Lamoot', 'bla bla', '2019-02-21 10:36:26'),
(10, 4, 2, 'Ruben Lamoot', 'you wish', '2019-02-21 09:55:33'),
(12, 1, 2, 'Ruben Lamoot', 'testing', '2019-02-28 13:42:28');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `caption`, `description`, `filename`, `alternate_text`, `type`, `size`, `created_at`, `updated_at`) VALUES
(1, 'Photo Belgium', 'blabla', '<p>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum en meer van dit</p>', '404.png', 'nog bla', 'jpg', 35, '2019-02-15 08:20:28', '2019-02-28 12:02:35'),
(2, 'Photo France', 'iets van da', 'france lorem ipsum lorem ipsum lorem ipsum lorem ipsum', '404.png', '', 'jpg', 40, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Sam', 'sam is sam', '<p>Lorem ipsum Sam</p>', '404.png', 'bla bla', '', 15, '2019-02-21 09:57:45', '2019-02-21 09:57:45'),
(4, 'my wife', '', '', 'getuige1.jpg', '', 'image/jpeg', 10196, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, '404 image', '', '', '404.png', '', 'image/png', 502197, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'sickboy', '', '', 'img_graphic.jpg', '', 'image/jpeg', 17390, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'young', 'zanger', '', 'neil.jpg', 'bla bla', 'image/jpeg', 18440, '2019-02-15 07:00:47', '2019-02-15 08:13:27'),
(9, 'Test', 'patat', '<p>bla bla bla bla bla bla</p>', 'avatar8.jpg', 'tester', 'image/jpeg', 4042, '2019-02-21 07:56:42', '2019-02-21 07:56:42');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `subcomments`
--

DROP TABLE IF EXISTS `subcomments`;
CREATE TABLE IF NOT EXISTS `subcomments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `date_time` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `subcomments`
--

INSERT INTO `subcomments` (`id`, `comment_id`, `user_id`, `body`, `date_time`) VALUES
(1, 1, 2, 'comment on comment', '2019-02-28 13:57:07'),
(2, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(3, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(4, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(5, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(6, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(7, 2, 2, 'comment on lore', '2019-02-28 14:07:03'),
(8, 2, 2, 'comment on lore', '2019-02-28 14:07:03');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `first_name` varchar(256) NOT NULL,
  `last_name` varchar(256) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`, `admin`) VALUES
(1, 'Tom', 'pass', 'Piet', 'Piraat2', 'avatar.jpg', 1),
(2, 'Ruben', 'twee', 'Ruben', 'Lamoot', 'avatar2.jpg', 1),
(3, 'Lore', 'drie', 'Lore', 'Vanhooren', 'avatar5.jpg', 0),
(4, 'Marieke', 'vier', 'Marieke', 'Decabooter', 'avatar6.png', 0),
(5, 'Brent', 'vijf', 'Brent', 'Vanhooren', 'avatar3.jpg', 0),
(12, 'Neville', 'zeven', 'Neville', 'Verleye', 'avatar4.jpg', 0),
(9, 'Brent', 'vijf', 'Brent', 'Vanhooren', '', 0),
(11, 'Brent', 'vijf', 'Brent', 'Vanhooren', 'avator11.jpg', 0),
(20, 'Andy', '12345', 'test', 'tester', 'avatar7.jpg', 1),
(14, 'Neville', 'zeven', 'Neville', 'Verleye', 'avator12_1550500172.jpg', 0),
(15, 'Neville', 'zeven', 'Neville', 'Verleye', 'avator12_1550500117.jpg', 0),
(17, 'Neville', 'zeven', 'Neville', 'Verleye', 'avatar10.jpg', 0),
(18, 'Neville', 'zeven', 'Neville', 'Verleye', 'avatar9.jpg', 0),
(19, 'tester2', '1458', 'testje', 'testertje', 'avatar8.jpg', 0),
(21, 'Anda', '12345', 'Anda', 'Nicosia', 'avator11_1551105151.jpg', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
